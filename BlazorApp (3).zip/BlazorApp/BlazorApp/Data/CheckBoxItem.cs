﻿namespace BlazorApp.Data
{
    public class CheckBoxItem
    {
        public List<string> selected_options { get; set; } = new();
    }
}
