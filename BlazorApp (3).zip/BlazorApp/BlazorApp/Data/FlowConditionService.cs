﻿//using Neo4j.Driver;

//namespace BlazorApp.Data
//{
//    public class FlowConditionService
//    {
//        var setting = await GetFlowConditionSetting("条件1");
//        var conditionList = JsonConvert.DeserializeObject<List<Condition>>(setting.conditions);

//foreach (var cond in conditionList)
//{
//    if (EvaluateCondition(cond)) // 条件に合ってたら
//    {
//        var query = @"
//            MATCH (fcs:FlowConditionSetting {name: $name})
//            MATCH (a:FlowApprovalClient {approval_id: $nextNodeId})
//            MERGE (fcs)-[:NEXT_TO]->(a)"
//        ;

//        await session.RunAsync(query, new
//        {
//            name = setting.name,
//            nextNodeId = cond.next_node_id
//    });
//    }
//}

//    }
//}
