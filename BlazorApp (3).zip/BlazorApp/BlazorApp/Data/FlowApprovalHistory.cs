﻿namespace BlazorApp.Data
{
    public class FlowApprovalHistory
    {
        public string? workflow_id { get; set; }
        public string? workflow_name { get; set; }

        public List<ApprovalHistory> approval_history = new List<ApprovalHistory>();
    }

    public class ApprovalHistory
    {
        public string? approval_id { get; set; }
        public string? approval_step { get; set; }
        public string? approval_type { get; set; }
        public string? status { get; set; }
        public string? comment { get; set; }
        public string? updated_datetime { get; set; }
    }
}
