﻿window.initScrollListener = (element, dotNetHelper) => {
    element.addEventListener("scroll", () => {
        if (element.scrollTop + element.clientHeight >= element.scrollHeight - 50) {
            dotNetHelper.invokeMethodAsync("OnScrollNearBottom");
        }
    });
}; 

//検索結果があればアコーディオンを自動的に閉じる
window.closeAccordion = function (accordionId) {
    var myCollapse = document.getElementById(accordionId);
    if (myCollapse && bootstrap) {
        var bsCollapse = bootstrap.Collapse.getInstance(myCollapse);
        if (!bsCollapse) {
            bsCollapse = new bootstrap.Collapse(myCollapse, { toggle: false });
        }
        bsCollapse.hide();
    }
};

//部品エリアからのフォームビルダーエリアへのドラック＆ドロップによる追加
window.setupDragula = (sourceId, targetId, dotNetHelper) => {
    const source = document.getElementById(sourceId);
    const target = document.getElementById(targetId);

    const drake = dragula([source, target], {
        copy: (el, src) => src === source,
        accepts: (el, target) => target.id === targetId,
        moves: (el, source, handle, sibling) => {
            // source-buttons内のボタンのみドラッグ可能
            return source.id === sourceId;
        }
    });

    drake.on('drop', function (el, target, source, sibling) {
        const type = el.getAttribute("data-type");

        if (type && target != null) {
            // sibling の前に入れる → その sibling の index を取得
            let index = 0;
            if (sibling) {
                index = Array.from(target.children).indexOf(sibling)-1;
            } else {
                index = target.children.length;
            }
            dotNetHelper.invokeMethodAsync("HandleDropWithIndex", type, index);
            el.remove(); // 仮DOMを削除
        }
    });
};

window.initializeDateTimePickers = function () {
    $('#datetimepicker1').datetimepicker({
        dayViewHeaderFormat: 'YYYY年 MMMM',
        tooltips: {
            close: '閉じる',
            selectMonth: '月を選択',
            prevMonth: '前月',
            nextMonth: '次月',
            selectYear: '年を選択',
            prevYear: '前年',
            nextYear: '次年',
            selectTime: '時間を選択',
            selectDate: '日付を選択',
            prevDecade: '前期間',
            nextDecade: '次期間',
            selectDecade: '期間を選択',
            prevCentury: '前世紀',
            nextCentury: '次世紀',
        },
        format: 'YYYY/MM/DD',
        locale: 'ja',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
        },
        buttons: {
            showClose: true,
        },
    });

    $('#datetimepicker2').datetimepicker({
        tooltips: {
            close: '閉じる',
            pickHour: '時間を取得',
            incrementHour: '時間を増加',
            decrementHour: '時間を減少',
            pickMinute: '分を取得',
            incrementMinute: '分を増加',
            decrementMinute: '分を減少',
            pickSecond: '秒を取得',
            incrementSecond: '秒を増加',
            decrementSecond: '秒を減少',
            togglePeriod: '午前/午後切替',
            selectTime: '時間を選択',
        },
        format: 'HH:mm',
        locale: 'ja',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
        },
        buttons: {
            showClose: true,
        },
    });

    $('#datetimepicker3').datetimepicker({
        dayViewHeaderFormat: 'YYYY年 MMMM',
        tooltips: {
            close: '閉じる',
            selectMonth: '月を選択',
            prevMonth: '前月',
            nextMonth: '次月',
            selectYear: '年を選択',
            prevYear: '前年',
            nextYear: '次年',
            selectTime: '時間を選択',
            selectDate: '日付を選択',
            prevDecade: '前期間',
            nextDecade: '次期間',
            selectDecade: '期間を選択',
            prevCentury: '前世紀',
            nextCentury: '次世紀',
            pickHour: '時間を取得',
            incrementHour: '時間を増加',
            decrementHour: '時間を減少',
            pickMinute: '分を取得',
            incrementMinute: '分を増加',
            decrementMinute: '分を減少',
            pickSecond: '秒を取得',
            incrementSecond: '秒を増加',
            decrementSecond: '秒を減少',
            togglePeriod: '午前/午後切替',
            selectTime: '時間を選択',
        },
        format: 'YYYY/MM/DD HH:mm',
        locale: 'ja',
        icons: {
            time: 'far fa-clock',
            date: 'far fa-calendar-alt',
            up: 'fas fa-arrow-up',
            down: 'fas fa-arrow-down',
        },
        buttons: {
            showClose: true,
        },
    });
};


//window.initializeDateTimePickersV6 = () => {
//    new tempusDominus.TempusDominus(document.getElementById('datetimepicker1'),
//        {
//            allowInputToggle: false,
//            container: undefined,
//            dateRange: false,
//            debug: false,
//            defaultDate: undefined,
//            display: {
//                icons: {
//                    type: 'icons',
//                    time: 'fa-solid fa-clock',
//                    date: 'fa-solid fa-calendar',
//                    up: 'fa-solid fa-arrow-up',
//                    down: 'fa-solid fa-arrow-down',
//                    previous: 'fa-solid fa-chevron-left',
//                    next: 'fa-solid fa-chevron-right',
//                    today: 'fa-solid fa-calendar-check',
//                    clear: 'fa-solid fa-trash',
//                    close: 'fa-solid fa-xmark'
//                },
//                sideBySide: false,
//                calendarWeeks: false,
//                viewMode: 'calendar',
//                toolbarPlacement: 'bottom',
//                keepOpen: false,
//                buttons: {
//                    today: false,
//                    clear: false,
//                    close: false
//                },
//                components: {
//                    calendar: true,
//                    date: true,
//                    month: true,
//                    year: true,
//                    decades: true,
//                    clock: true,
//                    hours: true,
//                    minutes: true,
//                    seconds: false,
//                    useTwentyfourHour: undefined
//                },
//                inline: false,
//                theme: 'auto',
//                keyboardNavigation: true
//            },
//            keepInvalid: false,
//            localization: {
//                clear: 'Clear selection',
//                close: 'Close the picker',
//                dateFormats: DefaultFormatLocalization.dateFormats,
//                dayViewHeaderFormat: { month: 'long', year: '2-digit' },
//                decrementHour: 'Decrement Hour',
//                decrementMinute: 'Decrement Minute',
//                decrementSecond: 'Decrement Second',
//                format: DefaultFormatLocalization.format,
//                hourCycle: DefaultFormatLocalization.hourCycle,
//                incrementHour: 'Increment Hour',
//                incrementMinute: 'Increment Minute',
//                incrementSecond: 'Increment Second',
//                locale: DefaultFormatLocalization.locale,
//                nextCentury: 'Next Century',
//                nextDecade: 'Next Decade',
//                nextMonth: 'Next Month',
//                nextYear: 'Next Year',
//                ordinal: DefaultFormatLocalization.ordinal,
//                pickHour: 'Pick Hour',
//                pickMinute: 'Pick Minute',
//                pickSecond: 'Pick Second',
//                previousCentury: 'Previous Century',
//                previousDecade: 'Previous Decade',
//                previousMonth: 'Previous Month',
//                previousYear: 'Previous Year',
//                selectDate: 'Select Date',
//                selectDecade: 'Select Decade',
//                selectMonth: 'Select Month',
//                selectTime: 'Select Time',
//                selectYear: 'Select Year',
//                startOfTheWeek: 0,
//                today: 'Go to today',
//                toggleMeridiem: 'Toggle Meridiem',
//                //toggleAriaLabel?: string
//            },
//            meta: {},
//            multipleDates: false,
//            multipleDatesSeparator: '; ',
//            promptTimeOnDateChange: false,
//            promptTimeOnDateChangeTransitionDelay: 200,
//            restrictions: {
//                minDate: undefined,
//                maxDate: undefined,
//                disabledDates: [],
//                enabledDates: [],
//                daysOfWeekDisabled: [],
//                disabledTimeIntervals: [],
//                disabledHours: [],
//                enabledHours: []
//            },
//            stepping: 1,
//            useCurrent: true,
//            viewDate: new Date()
//        })

//    new tempusDominus.TempusDominus(document.getElementById('datetimepicker2'), {
//        display: {
//            components: {
//                calendar: false,
//                clock: true,
//                hours: true,
//                minutes: true
//            }
//        }
//    });

//    new tempusDominus.TempusDominus(document.getElementById('datetimepicker3'), {
//        display: {
//            components: {
//                calendar: true,
//                clock: true,
//                hours: true,
//                minutes: true
//            }
//        }
//    });
//};

//window.dateTimePickerHelpers = {
//    attachFocusHandlers: function () {
//        console.log("attachFocusHandlers called");
//        document.querySelector('#datetimepicker1 .input-group-text').addEventListener('click', function () {
//            document.querySelector('#input1').focus();
//        });
//        document.querySelector('#datetimepicker2 .input-group-text').addEventListener('click', function () {
//            document.querySelector('#input2').focus();
//        });
//        document.querySelector('#datetimepicker3 .input-group-text').addEventListener('click', function () {
//            document.querySelector('#input3').focus();
//        });
//    }
//};
