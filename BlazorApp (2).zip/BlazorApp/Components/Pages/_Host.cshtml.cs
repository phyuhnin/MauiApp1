using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlazorApp.Components.Pages
{
    public class _HostModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
