﻿namespace BlazorApp.Data
{
    public class FlowItemFormApplyData
    {
        public string? ItemId { get; set; }

        public Dictionary<string, string> InputValue { get; set; } = new Dictionary<string, string>();
    }
}
