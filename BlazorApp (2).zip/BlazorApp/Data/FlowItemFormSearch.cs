﻿namespace BlazorApp.Data
{
    public class FlowItemFormSearch
    {
        public string? Category { get; set; }
        public string? FormId { get; set; }
        public string? FormName { get; set; }
        public bool StatusCreating { get; set; }
        public bool StatusProcessing { get; set; }
        public bool StatusCompleted { get; set; }
    }
}
