﻿namespace BlazorApp.Data
{
    public class AutoInputItem
    {
        public string? select_auto_input_format { get; set; }
        public List<string> auto_input_format = new List<string>()
            {
                "ユーザーID","ユーザー名","グループID","グループ名","役職","システム日付","システム日時","システム時刻","稟議ID",
                "稟議名","稟議申請グループ名","稟議申請グループID","部署ID","部署名","結合"
            };
        public string? select_setting_format { get; set; }
        //「入力区分」によって選択肢を動的に切り変える。システム日付・システム日時・システム時刻時のみ
        public List<string> setting_format = new List<string>()
            {
                "yyyy/MM/dd","yyyy-MM-dd","yyyy年MM月dd日","yyyy/MM/dd HH:mm","yyyy-MM-dd HH:mm","yyyy年MM月dd日 HH時mm分","HH:mm","HH時mm分"
            };
        public string? select_time_format { get; set; }
        //「入力区分」が日時・時刻の場合にのみ
        public List<string> time_format = new List<string>()
            {
                "12時間", "24時間"
            };
        public string? select_display { get; set; }
        public List<string> display = new List<string>()
                {
                    "表示", "非表示"
                };
        public string? select_is_edit { get; set; }
        public List<string> is_edit = new List<string>()
                {
                    "編集可", "編集不可"
                };
        public string? select_join_source { get; set; }
        //自動入力ソースが結合の場合のみ
        public List<string> join_source = new List<string>()
                {
                   "自動採番","フローID","フロー名","帳票ID","帳票名","稟議ID","稟議名","日付","固定値"
                };
        public string? select_join_point { get; set; }
        public List<string> join_point = new List<string>()
                {
                    "文字列型", "数値型"
                };
    }
}
