﻿namespace BlazorApp.Data
{
    public class Comment
    {
        public int comment_id { get; set; }
        public string? approval_type { get; set; }
        public string? role { get; set; }
        public string? comment { get; set; }
        public string? status { get; set; }
        public string? date { get; set; }
        public string? approval_user { get; set; }
    }
}
