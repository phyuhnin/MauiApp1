﻿namespace BlazorApp.Data
{
    public class CommentService
    {
        List<Comment> comments = new List<Comment>(); //DBはなかったのでとりあえずGlobal変数を使ってます。今後削除予定
        public Dictionary<string, string> GetHeader()
        {
            return new Dictionary<string, string>
            {
                {"comment_id", "コメントID" },
                { "approval_type", "投稿者種別" },
                { "role", "承認役職" },
                { "comment", "コメント " },
                { "status", "ステータス " },
                { "date", "投稿日時" },
                { "approval_user", "投稿者 " },
            };
        }

        public List<Comment> GetComments()
        {
            //List<Comment> comments = new List<Comment>();
            comments.Add(new Comment { comment_id = 1, approval_type = "申請者", role = "マネージャー", comment = "例の件確認済み", status = "承認時", date = "2025/04/18 10:00", approval_user = "田中" });
            comments.Add(new Comment { comment_id = 2, approval_type = "承認者", role = "部長", comment = "承認します", status = "承認時", date = "2025/04/18 10:15", approval_user = "佐藤" });
            comments.Add(new Comment { comment_id = 3, approval_type = "申請者", role = "マネージャー", comment = "再確認お願いします", status = "追加時", date = "2025/04/18 11:00", approval_user = "田中" });
            return comments;
        }

        public List<Comment> AddComment(Comment newcomment)
        {
            //List<Comment> comments = GetComments();
            var commentToAdd = new Comment
            {
                comment_id = comments.Count + 1,
                approval_type = "申請者",
                role = "マネージャー",
                comment = newcomment.comment,
                status = "承認時",
                date = "2025/04/18 10:00",
                approval_user = "ピュー"
            };
            //最新登録を先頭に表示
            comments.Insert(0, commentToAdd);
            // IDで降順ソートして返す
            var sortedComments = comments.OrderByDescending(c => c.comment_id).ToList();
            return sortedComments;
        }

        public List<Comment> EditComment(Comment selectedComment)
        {
            // 指定IDのコメントを検索
            var existingComment = comments.FirstOrDefault(c => c.comment_id == selectedComment.comment_id);
            if( existingComment != null )
            {
                // 内容を上書き
                existingComment.approval_type = selectedComment.approval_type;
                existingComment.role = selectedComment.role;
                existingComment.comment = selectedComment.comment;
                existingComment.status = selectedComment.status;
                existingComment.date = selectedComment.date;
                existingComment.approval_user = selectedComment.approval_user;
            }
            // IDで降順ソートして返す
            return comments.OrderByDescending(c => c.comment_id).ToList();
        }


    }
}
