﻿namespace BlazorApp.Data
{
    public class InputComponent
    {
        public string Type { get; set; } = string.Empty; // "TextBox", "CheckBox", etc.
        public string Label { get; set; } = string.Empty;
        public List<string> Options { get; set; } = new();
        public CommonSettingItem CommonSettings { get; set; } = new();
        public TextboxItem TextboxItems { get; set; } = new();
        public CheckBoxItem CheckBoxItems { get; set; } = new();
        public SelectItem SelectItems { get; set; } = new();
        public LinkItem LinkItems { get; set; } = new();
        public AutoInputItem AutoInputItems { get; set; } = new();
        public DateTimeItem DateTimeItems { get; set; } = new();
        public SameFormInputItem SameFormInputItems { get; set; } = new();
    }

    //public class InputComponentList
    //{
    //    public Dictionary<string, object> data { get; set; } = new();
    //}

    public enum InputTypeEnum
    {
        Text,
        TextArea,
        DateTime,
        DropDown,
        CheckBox,
        UserSearch,
        GroupSearch,
        PositionSearch,
        Link
    }

}
