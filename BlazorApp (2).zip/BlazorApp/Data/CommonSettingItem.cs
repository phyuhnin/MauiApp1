﻿namespace BlazorApp.Data
{
    public class CommonSettingItem
    {
        //public string? item_id { get; set; }
        public string? input_type { get; set; }// "TextBox", "CheckBox", etc.
        //public string? name { get; set; } //userName
        public string? label { get; set; } //ユーザー名
        public string? placeholder { get; set; }
        public string? initial_value { get; set; }
        public string? select_require { get; set; }
        public List<string> require = new List<string>()
            {
                "システム必須", "必須", "任意"
            };
        public string? select_input_user { get; set; }
        public List<string> input_user { get; set; } = new List<string>()
            {
                "申請者", "承認者"
            };
        public string? select_print_setting { get; set; }
        public List<string> print_setting { get; set; } = new List<string>()
            {
                "含む", "含まない"
            };
        public string? display_no { get; set; }
    }
}


