﻿namespace BlazorApp.Data
{
    public class UserInputItem
    {
    }
}
