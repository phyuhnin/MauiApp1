﻿namespace BlazorApp.Data
{
    public class Flow
    {
        public string? flow_id { get; set; }
        public string? flow_name { get; set; }
        public string? flow_category { get; set; }
        public string? flow_version { get; set; }
        public string? status { get; set; }
        public string? service_start_date { get; set; }
        public string? service_end_date { get; set; }
        public string? usage_permission { get; set; }
        public string? allowed_group { get; set; }
        public string? application_flow_id_setting { get; set; }
        public string? application_flow_id_rule1 { get; set; }
        public string? application_flow_id_rule2 { get; set; }
        public string? application_flow_id_rule3 { get; set; }
        public string? application_flow_id_rule4 { get; set; }
        public string? application_flow_id_rule5 { get; set; }
        public string? application_flow_id { get; set; }
        public string? fixed_value { get; set; }
        public string? year_month { get; set; }
        public string? serial_number { get; set; }
        public string? naming_rules_setting { get; set; }
        public string? naming_rule1 { get; set; }
        public string? naming_rule2 { get; set; }
        public string? naming_rule3 { get; set; }
        public string? naming_rule4 { get; set; }
        public string? naming_rule5 { get; set; }
        public string? naming_rule { get; set; }
        //指示グループ
        //参照権限
        //申請指示の意味と申請グループの指示者所属グループ
    }
}
