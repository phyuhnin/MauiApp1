﻿namespace BlazorApp.Data
{
    public class DateTimeItem
    {
        public string? select_input_format { get; set; }
        public List<string> input_format = new List<string>()
            {
                "日付", "日時","時刻"
            };
        public string? select_setting_format { get; set; }
        public List<string> setting_format = new List<string>()
            {
                "yyyy/MM/dd","yyyy-MM-dd","yyyy年MM月dd日","yyyy/MM/dd HH:mm","yyyy-MM-dd HH:mm","yyyy年MM月dd日 HH時mm分","HH:mm","HH時mm分"
            };
        public string? select_time_format { get; set; }
        //「入力区分」が日時・時刻の場合にのみ
        public List<string> time_format = new List<string>()
            {
                "12時間", "24時間"
            };
        public string? select_max_value_category { get; set; }
        public List<string> max_value_category = new List<string>()
        {
            "手動","自動計算"
        };
        public string? select_min_value_category { get; set; }
        public List<string> min_value_category = new List<string>()
        {
            "手動","自動計算"
        };
        public string? max_value { get; set; }
        public string? min_value { get; set; }
    }
}
