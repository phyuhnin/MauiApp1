﻿namespace BlazorApp.Data
{
    public class TextboxItem
    {
        public string? select_input_format { get; set; }
        public List<string> input_format = new List<string>()
            {
                "文字列型", "数値型"
            };
    }
}
