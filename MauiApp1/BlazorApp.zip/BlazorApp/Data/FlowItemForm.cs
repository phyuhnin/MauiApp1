﻿namespace BlazorApp.Data
{
    public class FlowItemForm
    {
        public string? form_id { get; set; }
        public string? form_name { get; set; }
        public string? form_category { get; set; }
        public string? status { get; set; }
        public string? allowed_update { get; set; }
        public string? updated_datetime { get; set; }
        public string? updated_user { get; set; }
        public string? form_version { get; set; }
    }
}
