﻿namespace BlazorApp.Data
{
    public class FlowConditionSetting
    {
        public string? logical_item_no { get; set; }
        public string? logical_disjunction { get; set; }
        public string? logical_item_type { get; set; }
        public string? logical_value1 { get; set; }
        public string? logical_operator { get; set; }
        public string? logical_value2 { get; set; }
        public string? next_node_id { get; set; }
        public string? next_node_name { get; set; }
    }
}
