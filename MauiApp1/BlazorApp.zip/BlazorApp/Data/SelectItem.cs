﻿namespace BlazorApp.Data
{
    public class SelectItem
    {
        public List<string> selected_options { get; set; } = new List<string>();

        public string? select_option_setting_category { get; set; }
        public List<string> option_setting_category { get; set; } = new List<string>()
            {
                "手動", "自動"
            };

        public string? select_auto_input_select_item { get; set; }
        public List<string> auto_input_select_item { get; set; } = new List<string>()
            {
                "所属グループ", "所属役職","所属部署","ユーザー情報"
            };

        public string? select_user_info { get; set; }
        public List<string> user_info { get; set; } = new List<string>()
            {
                "ユーザーID", "ユーザー名","所属部署"
            };
    }
}
