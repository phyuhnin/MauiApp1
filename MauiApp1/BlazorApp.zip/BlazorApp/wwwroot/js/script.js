﻿window.initScrollListener = (element, dotNetHelper) => {
    element.addEventListener("scroll", () => {
        if (element.scrollTop + element.clientHeight >= element.scrollHeight - 50) {
            dotNetHelper.invokeMethodAsync("OnScrollNearBottom");
        }
    });
}; 

//検索結果があればアコーディオンを自動的に閉じる
window.closeAccordion = function (accordionId) {
    var myCollapse = document.getElementById(accordionId);
    if (myCollapse && bootstrap) {
        var bsCollapse = bootstrap.Collapse.getInstance(myCollapse);
        if (!bsCollapse) {
            bsCollapse = new bootstrap.Collapse(myCollapse, { toggle: false });
        }
        bsCollapse.hide();
    }
};

//部品エリアからのフォームビルダーエリアへのドラック＆ドロップによる追加
window.setupDragula = (sourceId, targetId, dotNetHelper) => {
    const source = document.getElementById(sourceId);
    const target = document.getElementById(targetId);

    const drake = dragula([source, target], {
        copy: (el, src) => src === source,
        accepts: (el, target) => target.id === targetId,
        moves: (el, source, handle, sibling) => {
            // source-buttons内のボタンのみドラッグ可能
            return source.id === sourceId;
        }
    });

    drake.on('drop', function (el, target, source, sibling) {
        const type = el.getAttribute("data-type");

        if (type && target != null) {
            // sibling の前に入れる → その sibling の index を取得
            let index = 0;
            if (sibling) {
                index = Array.from(target.children).indexOf(sibling)-1;
            } else {
                index = target.children.length;
            }
            dotNetHelper.invokeMethodAsync("HandleDropWithIndex", type, index);
            el.remove(); // 仮DOMを削除
        }
    });
};


